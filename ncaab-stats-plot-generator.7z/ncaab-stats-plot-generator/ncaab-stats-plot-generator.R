##############################################################
# Script name: NCAA Basketball Stats Plot Generator
# Version: 1.0
# By: Rodrigo Zamith
# License: MPL 2.0
##############################################################

################# LOAD LIBRARIES
library("Cairo")
library("ggplot2")
library("gridExtra")
library("psych")
library("reshape")
library("scales")
library("sm")

################# LOAD DATA
# Load aggregate player data
agg.player <- read.csv(file="data/summary_player_data.tsv", sep="\t", header=TRUE, row.names=1, na.strings="�")
agg.player$player_name <- as.character(agg.player$player_name)
agg.player$team_name <- as.character(agg.player$team_name)
agg.player$pos <- factor(agg.player$pos, c("G", "F", "C"))
agg.player$year <- factor(agg.player$year, c("Fr", "So", "Jr", "Sr"))
agg.player$height = sapply(strsplit(as.character(agg.player$height), "-"), function(x){12*as.numeric(x[1]) + as.numeric(x[2])})
agg.player$minutes = sapply(strsplit(as.character(agg.player$minutes), ":"), function(x){as.numeric(x[1]) + as.numeric(x[2])/60})

# Load aggregate team data
agg.team <- read.csv(file="data/summary_team_data.tsv", sep="\t", header=TRUE, row.names=1, na.strings="�")
agg.team$team_name <- as.character(agg.team$team_name)
agg.team$team_minutes = sapply(strsplit(as.character(agg.team$team_minutes), ":"), function(x){as.numeric(x[1]) + as.numeric(x[2])/60})
agg.team$opp_team_minutes = sapply(strsplit(as.character(agg.team$opp_team_minutes), ":"), function(x){as.numeric(x[1]) + as.numeric(x[2])/60})

# Load Individual Game Data
ind.game <- read.csv(file="data/game_data.tsv", sep="\t", header=TRUE, row.names=1, na.strings="�")
ind.game$game_date <- as.Date(ind.game$game_date, format='%m/%d/%Y')
ind.game$home_team_name <- as.character(ind.game$home_team_name)
ind.game$away_team_name <- as.character(ind.game$away_team_name)
ind.game$home_team_minutes = sapply(strsplit(as.character(ind.game$home_team_minutes), ":"), function(x){as.numeric(x[1]) + as.numeric(x[2])/60})
ind.game$away_team_minutes = sapply(strsplit(as.character(ind.game$away_team_minutes), ":"), function(x){as.numeric(x[1]) + as.numeric(x[2])/60})


# Load Individual Player Data
ind.player <- read.csv(file="data/player_data.tsv", sep="\t", header=TRUE, row.names=NULL, na.strings="�")
ind.player$player_name <- as.character(ind.player$player_name)
ind.player$team_name <- as.character(ind.player$team_name)
ind.player$pos <- factor(ind.player$pos, c("G", "F", "C"))
ind.player$minutes = sapply(strsplit(as.character(ind.player$minutes), ":"), function(x){as.numeric(x[1]) + as.numeric(x[2])/60})
ind.player$game_date <- as.Date(ind.player$game_date, format='%m/%d/%Y')

# Load Variable Names (to label axes when generating graphs)
varnames <- read.csv(file="data/varnames.csv", header=TRUE, row.names=NULL)

# Create a vector with all of the 64 teams in the NCAA Tournament
tourneyteams <- c("328", "251", "235", "418", "740", "110", "626", "457", "739", "522", "428", "5", "649", "508", "28755", "772", "260", "518", "473", "327", "796", "29", "513", "545", "782", "311", "14927", "433", "340", "275", "310", "665", "306", "415", "387", "688", "465", "87", "301", "490", "690", "157", "83", "107", "441", "173", "534", "317", "367", "193", "416", "609", "521", "404", "169", "156", "434", "140", "610", "529", "472", "735", "14", "488")



################# TAKE OUR EXISTING DATA, ADD TO IT, AND CREATE NEW DATAFRAMES
##### Create a list with our basic stats
basicgamestats <- c("fgm", "fga", "three_fgm", "three_fga", "ft", "fta", "pts", "ptsavg", "offreb", "defreb", "totreb", "rebavg", "ast", "to", "stl", "blk", "fouls", "dbldbl", "trpdbl")
basicgamestats_team <- basicgamestats


##### Add a few pieces of data to each game
# Point differential for each game
ind.game$ptsdiff <- ind.game$home_team_pts - ind.game$away_team_pts
# Field goal percentage
ind.game$away_team_fgpct <- ind.game$away_team_fgm/ind.game$away_team_fga
ind.game$home_team_fgpct <- ind.game$home_team_fgm/ind.game$home_team_fga
# Three-point percentage
ind.game$away_team_three_fgpct <- ind.game$away_team_three_fgm/ind.game$away_team_three_fga
ind.game$home_team_three_fgpct <- ind.game$home_team_three_fgm/ind.game$home_team_three_fga
# Free-throw percentage
ind.game$away_team_ftpct <- ind.game$away_team_ft/ind.game$away_team_fta
ind.game$home_team_ftpct <- ind.game$home_team_ft/ind.game$home_team_fta

# Add our changes to our list of variables
basicgamestatsaddpct <- c("fgpct", "three_fgpct", "ftpct")
basicgamestats_team <- append(basicgamestats_team, basicgamestatsaddpct)
basicgamestatsaddunique <- c("ptsdiff")


##### Calculate additional team data
# Create a vector with each team
agg.team.teams <- row.names(agg.team)

# Create empty vectors to later populate and transform into data frame
vec_home_avg_ptsdiff <- NULL
vec_away_avg_ptsdiff <- NULL
vec_avg_ptsdiff <- NULL
vec_home_wins <- NULL
vec_away_wins <- NULL
vec_wins <- NULL
vec_home_losses <- NULL
vec_away_losses <- NULL
vec_losses <- NULL
vec_winpct <- NULL
vec_guard_points <- NULL
vec_guard_avg_height <- NULL
vec_forward_points <- NULL
vec_forward_avg_height <- NULL

# Parse each team and generate statistics
for (team in seq(along=agg.team.teams)) {
  gen_team_id <- as.character(agg.team.teams[team])
  gen_agg_team_stats <- agg.team[gen_team_id, ]
  gen_agg_player_stats <- agg.player[agg.player$team_id == gen_team_id, ]
  
  # Calculate a handful of general team statistics
  gen_home_ptsdiff <- ind.game[ind.game$home_team_id == gen_team_id, ]$ptsdiff
  gen_away_ptsdiff <- ind.game[ind.game$away_team_id == gen_team_id, ]$ptsdiff * -1
  gen_total_ptsdiff <- c(gen_home_ptsdiff, gen_away_ptsdiff)
  gen_home_avg_ptsdiff <- mean(gen_home_ptsdiff)
  gen_away_avg_ptsdiff <- mean(gen_away_ptsdiff)
  gen_avg_ptsdiff <- mean(gen_total_ptsdiff)
  gen_home_wins <- length(which(gen_home_ptsdiff > 0))
  gen_away_wins <- length(which(gen_away_ptsdiff > 0))
  gen_wins <- gen_home_wins + gen_away_wins
  gen_home_losses <- length(which(gen_home_ptsdiff < 0))
  gen_away_losses <- length(which(gen_away_ptsdiff < 0))
  gen_losses <- gen_home_losses + gen_away_losses
  gen_winpct <- (gen_wins)/(gen_wins+gen_losses)  
  
  # Calculate a handful of position-specific stats
  gen_guards <- gen_agg_player_stats[gen_agg_player_stats$pos == "G", ]
  gen_guard_points <- sum(gen_guards$pts, na.rm=TRUE)/sum(gen_agg_team_stats$team_pts, na.rm=TRUE)
  gen_guard_avg_height <- mean(gen_guards$height, na.rm=TRUE)
  gen_forwards <- gen_agg_player_stats[grep("F|C", gen_agg_player_stats$pos), ]
  gen_forward_points <- sum(gen_forwards$pts, na.rm=TRUE)/sum(gen_agg_team_stats$team_pts, na.rm=TRUE)
  gen_forward_avg_height <- mean(gen_forwards$height, na.rm=TRUE)
  
  # Append these variables to their respective vectors to add to data frame
  vec_home_avg_ptsdiff <- append(vec_home_avg_ptsdiff, gen_home_avg_ptsdiff)
  vec_away_avg_ptsdiff <- append(vec_away_avg_ptsdiff, gen_away_avg_ptsdiff)
  vec_avg_ptsdiff <- append(vec_avg_ptsdiff, gen_avg_ptsdiff)
  vec_home_wins <- append(vec_home_wins, gen_home_wins)
  vec_away_wins <- append(vec_away_wins, gen_away_wins)
  vec_wins <- append(vec_wins, gen_wins)
  vec_home_losses <- append(vec_home_losses, gen_home_losses)
  vec_away_losses <- append(vec_away_losses, gen_away_losses)
  vec_losses <- append(vec_losses, gen_losses)
  vec_winpct <- append(vec_winpct, gen_winpct)
  vec_guard_points <- append(vec_guard_points, gen_guard_points)
  vec_guard_avg_height <- append(vec_guard_avg_height, gen_guard_avg_height)
  vec_forward_points <- append(vec_forward_points, gen_forward_points)
  vec_forward_avg_height <- append(vec_forward_avg_height, gen_forward_avg_height)
  
}

# Add our extra bits of data to the agg.data frame
agg.team$team_home_avg_ptsdiff <- vec_home_avg_ptsdiff
agg.team$team_away_avg_ptsdiff <- vec_away_avg_ptsdiff
agg.team$team_avg_ptsdiff <- vec_avg_ptsdiff
agg.team$team_home_wins <- vec_home_wins
agg.team$team_away_wins <- vec_away_wins
agg.team$team_wins <- vec_wins
agg.team$team_home_losses <- vec_home_losses
agg.team$team_away_losses <- vec_away_losses
agg.team$team_losses <- vec_losses
agg.team$team_winpct <- vec_winpct
agg.team$team_guard_points <- vec_guard_points
agg.team$team_guard_avg_height <- vec_guard_avg_height
agg.team$team_forward_points <- vec_forward_points
agg.team$team_forward_avg_height <- vec_forward_avg_height

# Erase any existing data frame-populating vectors
rm(list = ls(pattern = "\\bvec_"))
rm(list = ls(pattern = "\\bgen_"))

# Add a few more elements to our vector of variables
basicgamestatsaddsingle <- c("home_avg_ptsdiff","away_avg_ptsdiff","avg_ptsdiff","home_wins","away_wins","wins","home_losses","away_losses","losses","winpct","guard_points","guard_avg_height","forward_points","forward_avg_height")
basicgamestats_team <- append(basicgamestats_team, basicgamestatsaddsingle)


##### Append new team data to each game
# Create our list of games
ind.game.games <- row.names(ind.game)

home_away_vars_to_populate <- NULL
for (variable in seq(along=basicgamestats_team)) {
  gen_var_name <- basicgamestats_team[variable]
  home_away_vars_to_populate <- append(home_away_vars_to_populate, paste0("team_", gen_var_name))
}

# Create empty vectors for the information to be added
for (variable in seq(along=home_away_vars_to_populate)) {
  gen_var_name <- home_away_vars_to_populate[variable]
  command <- paste0("gen_var_away_vec_", gen_var_name, " <- NULL")
  eval(parse(text=command))
  command <- paste0("gen_var_home_vec_", gen_var_name, " <- NULL")
  eval(parse(text=command))
}
  
# Parse each game and generate statistics
for (game in seq(along=ind.game.games)) {
  gen_game_id <- ind.game.games[game]
  gen_away_team_id <- as.character(ind.game[gen_game_id, ]$away_team_id)
  gen_home_team_id <- as.character(ind.game[gen_game_id, ]$home_team_id)
  
  # For each one of our variables
  for (variable in seq(along=home_away_vars_to_populate)) {
    gen_var_name <- home_away_vars_to_populate[variable]
    
    # Get values from team data frame
    command <- paste0("gen_values_away_", gen_var_name, " <- agg.team['", gen_away_team_id, "', ]$", gen_var_name)
    eval(parse(text=command))
    command <- paste0("gen_values_home_", gen_var_name, " <- agg.team['", gen_home_team_id, "', ]$", gen_var_name)
    eval(parse(text=command))

    # Append it to our earlier vector
    command <- paste0("gen_var_away_vec_", gen_var_name, " <- append(gen_var_away_vec_", gen_var_name, ", gen_values_away_", gen_var_name, ")")
    eval(parse(text=command))
    command <- paste0("gen_var_home_vec_", gen_var_name, " <- append(gen_var_home_vec_", gen_var_name, ", gen_values_home_", gen_var_name, ")")
    eval(parse(text=command))
  }
}

# Add the data to the data frame
for (variable in seq(along=home_away_vars_to_populate)) {
  gen_var_name <- home_away_vars_to_populate[variable]
  command <- paste0("ind.game$away_season_", gen_var_name, " <- gen_var_away_vec_", gen_var_name)
  eval(parse(text=command))
  command <- paste0("ind.game$home_season_", gen_var_name, " <- gen_var_home_vec_", gen_var_name)
  eval(parse(text=command))
}

# Erase any existing data frame-populating vectors
rm(list = ls(pattern = "\\bvec_"))
rm(list = ls(pattern = "\\bgen_"))


##### Create a new team-level data frame that has individual game stats and looks like: Team Stats, Opponent Stats (Note: Each game will thus have two entries!)
# First, the away team
vec_team_away <- data.frame(thisteam_team_id = ind.game$away_team_id, thisteam_team_name = ind.game$away_team_name, game_id = row.names(ind.game), game_date = ind.game$game_date, neutral_site = ind.game$neutral_site, home = 0, opp_team_id = ind.game$home_team_id, opp_team_name = ind.game$home_team_name)
for (variable in seq(along=basicgamestats_team)) {
  gen_var_name <- basicgamestats_team[variable]
  command <- paste0("vec_team_away$thisteam_", gen_var_name, " = ind.game$away_team_", gen_var_name)
  eval(parse(text=command))
  command <- paste0("vec_team_away$opp_", gen_var_name, " = ind.game$home_team_", gen_var_name)
  eval(parse(text=command))
  command <- paste0("vec_team_away$thisteam_season_", gen_var_name, " = ind.game$away_season_team_", gen_var_name)
  eval(parse(text=command))
  command <- paste0("vec_team_away$opp_season_", gen_var_name, " = ind.game$home_season_team_", gen_var_name)
  eval(parse(text=command))
}
for (variable in seq(along=basicgamestatsaddunique)) {
  gen_var_name <- basicgamestatsaddunique[variable]
  command <- paste0("vec_team_away$", gen_var_name, " = ind.game$", gen_var_name)
  eval(parse(text=command))
}
vec_team_away$ptsdiff <- vec_team_away$ptsdiff * -1 # The way we calculate ptsdiff is Home Team Score - Away Team Score, so we need to take the inverse here.

# Then, the home team
vec_team_home <- data.frame(thisteam_team_id = ind.game$home_team_id, thisteam_team_name = ind.game$home_team_name, game_id = row.names(ind.game), game_date = ind.game$game_date, neutral_site = ind.game$neutral_site, home = 1, opp_team_id = ind.game$away_team_id, opp_team_name = ind.game$away_team_name)
for (variable in seq(along=basicgamestats_team)) {
  gen_var_name <- basicgamestats_team[variable]
  command <- paste0("vec_team_home$thisteam_", gen_var_name, " = ind.game$home_team_", gen_var_name)
  eval(parse(text=command))
  command <- paste0("vec_team_home$opp_", gen_var_name, " = ind.game$away_team_", gen_var_name)
  eval(parse(text=command))
  command <- paste0("vec_team_home$thisteam_season_", gen_var_name, " = ind.game$home_season_team_", gen_var_name)
  eval(parse(text=command))
  command <- paste0("vec_team_home$opp_season_", gen_var_name, " = ind.game$away_season_team_", gen_var_name)
  eval(parse(text=command))
}
for (variable in seq(along=basicgamestatsaddunique)) {
  gen_var_name <- basicgamestatsaddunique[variable]
  command <- paste0("vec_team_home$", gen_var_name, " = ind.game$", gen_var_name)
  eval(parse(text=command))
}

# Bind the two dataframes into ind.team, which will have team-level data for each game
ind.team <- rbind(vec_team_away, vec_team_home)

# Erase any existing data frame-populating vectors
rm(list = ls(pattern = "\\bvec_"))
rm(list = ls(pattern = "\\bgen_"))


##### Add in opponents' winning percentage, etc. (all stats from basicgamestatsaddsingle, but for opponents)
# Create a vector with each team
agg.team.teams <- row.names(agg.team)

# Create empty vectors for the information to be added
for (variable in seq(along=basicgamestatsaddsingle)) {
  gen_var_name <- basicgamestatsaddsingle[variable]
  command <- paste0("gen_var_vec_opp_season_", gen_var_name, " <- NULL")
  eval(parse(text=command))
}

# Parse each TEAM and generate statistics
for (team in seq(along=agg.team.teams)) {
  gen_team_id <- as.character(agg.team.teams[team])

  # For each one of our variables
  for (variable in seq(along=basicgamestatsaddsingle)) {
    gen_var_name <- basicgamestatsaddsingle[variable]
    
    # Calculate means for each variable
    command <- paste0("gen_values_opp_season_", gen_var_name, " <- mean(ind.team[ind.team$thisteam_team_id == ", gen_team_id, ", ]$opp_season_", gen_var_name, ", na.rm = TRUE)")
    eval(parse(text=command))
    
    # Append it to our earlier vector
    command <- paste0("gen_var_vec_opp_season_", gen_var_name, " <- append(gen_var_vec_opp_season_", gen_var_name, ", gen_values_opp_season_", gen_var_name, ")")
    eval(parse(text=command))
    
    command <- paste0("head(gen_var_vec_opp_season_", gen_var_name, ")")
    eval(parse(text=command))
  }
}

# Add the data to the data frame
for (variable in seq(along=basicgamestatsaddsingle)) {
  gen_var_name <- basicgamestatsaddsingle[variable]
  command <- paste0("agg.team$opp_team_", gen_var_name, " <- gen_var_vec_opp_season_", gen_var_name)
  eval(parse(text=command))
}

# Erase any existing data frame-populating vectors
rm(list = ls(pattern = "\\bvec_"))
rm(list = ls(pattern = "\\bgen_"))


##### Now, we append all of that opponent data to each game
# Create our list of games
ind.game.games <- row.names(ind.game)

# Determine what variables need to be populated
opp_vars_to_populate <- NULL
for (variable in seq(along=basicgamestatsaddsingle)) {
  gen_var_name <- basicgamestatsaddsingle[variable]
  opp_vars_to_populate <- append(opp_vars_to_populate, paste0("opp", gen_var_name))
}

# Create empty vectors for the information to be added
for (variable in seq(along=basicgamestatsaddsingle)) {
  gen_var_name <- basicgamestatsaddsingle[variable]
  command <- paste0("gen_var_away_vec_", gen_var_name, " <- NULL")
  eval(parse(text=command))
  command <- paste0("gen_var_home_vec_", gen_var_name, " <- NULL")
  eval(parse(text=command))
}

# Parse each game and generate statistics
for (game in seq(along=ind.game.games)) {
  gen_game_id <- ind.game.games[game]
  gen_away_team_id <- as.character(ind.game[gen_game_id, ]$away_team_id)
  gen_home_team_id <- as.character(ind.game[gen_game_id, ]$home_team_id)
  
  # For each one of our variables
  for (variable in seq(along=basicgamestatsaddsingle)) {
    gen_var_name <- basicgamestatsaddsingle[variable]
    
    # Get values from team data frame
    command <- paste0("gen_values_away_", gen_var_name, " <- agg.team['", gen_away_team_id, "', ]$opp_team_", gen_var_name)
    eval(parse(text=command))
    command <- paste0("gen_values_home_", gen_var_name, " <- agg.team['", gen_home_team_id, "', ]$opp_team_", gen_var_name)
    eval(parse(text=command))
    
    # Append it to our earlier vector
    command <- paste0("gen_var_away_vec_", gen_var_name, " <- append(gen_var_away_vec_", gen_var_name, ", gen_values_away_", gen_var_name, ")")
    eval(parse(text=command))
    command <- paste0("gen_var_home_vec_", gen_var_name, " <- append(gen_var_home_vec_", gen_var_name, ", gen_values_home_", gen_var_name, ")")
    eval(parse(text=command))
  }
}

# Add the data to the data frame
for (variable in seq(along=basicgamestatsaddsingle)) {
  gen_var_name <- basicgamestatsaddsingle[variable]
  command <- paste0("ind.game$away_season_opp_", gen_var_name, " <- gen_var_away_vec_", gen_var_name)
  eval(parse(text=command))
  command <- paste0("ind.game$home_season_opp_", gen_var_name, " <- gen_var_home_vec_", gen_var_name)
  eval(parse(text=command))
}


# Erase any existing data frame-populating vectors
rm(list = ls(pattern = "\\bvec_"))
rm(list = ls(pattern = "\\bgen_"))


#### And now we take that opponent data and feed it back into our aggregate team dataframe
# First, the away team
vec_team_away <- data.frame(row.names=row.names(ind.team))
for (variable in seq(along=basicgamestatsaddsingle)) {
  gen_var_name <- basicgamestatsaddsingle[variable]
  command <- paste0("vec_team_away$thisteam_season_opp_", gen_var_name, " = ind.game$away_season_opp_", gen_var_name)
  eval(parse(text=command))
  command <- paste0("vec_team_away$opp_season_opp_", gen_var_name, " = ind.game$home_season_opp_", gen_var_name)
  eval(parse(text=command))
}

# Then, the home team
vec_team_home <- data.frame(row.names=row.names(ind.team))
for (variable in seq(along=basicgamestatsaddsingle)) {
  gen_var_name <- basicgamestatsaddsingle[variable]
  command <- paste0("vec_team_home$thisteam_season_opp_", gen_var_name, " = ind.game$home_season_opp_", gen_var_name)
  eval(parse(text=command))
  command <- paste0("vec_team_home$opp_season_opp_", gen_var_name, " = ind.game$away_season_opp_", gen_var_name)
  eval(parse(text=command))
}

vec_ind.team <- rbind(vec_team_away, vec_team_home)
ind.team <- cbind(ind.team, vec_team_away, vec_team_home)

# Erase any existing data frame-populating vectors
rm(list = ls(pattern = "\\bvec_"))
rm(list = ls(pattern = "\\bgen_"))



################# NOW, WE'RE READY TO PLOT! ALL PLOTS GO IN ./PLOTS/
#### Preparations for plotting
# Set the field of Tournament foe
tourney_team_agg_stats <- agg.team[tourneyteams, ]
tourney_team_ind_stats <- subset(ind.team, thisteam_team_id %in% tourneyteams)
tourney_player_ind_stats <- subset(ind.player, team_id %in% tourneyteams)

# Melt the data for percentile rankings
tourney_team_agg_stats.m <- melt(tourney_team_agg_stats[c("team_name", "team_fgpct", "team_three_fgpct", "team_ptsavg", "team_offreb", "team_rebavg", "team_ast", "team_to", "team_stl", "team_blk", "opp_team_fgpct", "opp_team_three_fgpct", "opp_team_ptsavg", "opp_team_offreb", "opp_team_rebavg", "opp_team_ast", "opp_team_to", "opp_team_stl", "opp_team_blk", "team_avg_ptsdiff", "opp_team_avg_ptsdiff")])
tourney_team_agg_stats.m[is.na(tourney_team_agg_stats.m)] <- 0
tourney_team_agg_stats.rescale <- ddply(tourney_team_agg_stats.m, .(variable), transform, rescale = scale(value))
tourney_team_agg_stats.percentile <-  ddply(tourney_team_agg_stats.m, .(variable), transform, percentile=ecdf(value)(value))

# Create lists of variables we want to plot, by dataframe
ind.player.plot <- c("three_fga", "three_fgm", "ast", "blk", "fga", "fgm", "fouls", "fta", "ft", "pts", "defreb", "offreb", "totreb", "stl", "to")
ind.team.plot <- c("three_fgpct", "three_fga", "three_fgm", "ast", "blk", "fgpct", "fga", "fgm", "fouls", "ftpct", "fta", "ft", "pts", "defreb", "offreb", "stl", "totreb", "to")
agg.team.plot <- c("three_fgpct", "three_fga", "three_fgm", "ast", "forward_avg_height", "guard_avg_height", "avg_ptsdiff", "away_avg_ptsdiff", "home_avg_ptsdiff", "ptsavg", "rebavg", "blk", "fgpct", "fga", "fgm", "fouls", "ftpct", "fta", "ft", "losses", "away_losses", "home_losses", "forward_points", "guard_points", "pts", "defreb", "offreb", "totreb", "stl", "to", "winpct", "away_wins", "home_wins", "wins")

# Get Min, Mean, and Max (to set limits for Y axes in each plot).
range_team_agg_stats <- data.frame(stats=c("min", "mean", "max"))
for (variable in seq(along=agg.team.plot)) {
  gen_var_name <- agg.team.plot[variable]
  command <- paste0("try(range_team_agg_stats$", gen_var_name, " <- c(min(agg.team$team_", gen_var_name, ", na.rm=TRUE), mean(agg.team$team_", gen_var_name, ", na.rm=TRUE), max(agg.team$team_", gen_var_name, ", na.rm=TRUE)))")
  eval(parse(text=command))
}

range_team_ind_stats <- data.frame(stats=c("min", "mean", "max"))
for (variable in seq(along=ind.team.plot)) {
  gen_var_name <- ind.team.plot[variable]
  command <- paste0("try(range_team_ind_stats$", gen_var_name, " <- c(min(ind.team$thisteam_", gen_var_name, ", na.rm=TRUE), mean(ind.team$thisteam_", gen_var_name, ", na.rm=TRUE), max(ind.team$thisteam_", gen_var_name, ", na.rm=TRUE)))")
  eval(parse(text=command))
}

range_player_ind_stats <- data.frame(stats=c("min", "mean", "max"))
for (variable in seq(along=ind.player.plot)) {
  gen_var_name <- ind.player.plot[variable]
  command <- paste0("try(range_player_ind_stats$", gen_var_name, " <- c(min(ind.player$", gen_var_name, ", na.rm=TRUE), mean(ind.player$", gen_var_name, ", na.rm=TRUE), max(ind.player$", gen_var_name, ", na.rm=TRUE)))")
  eval(parse(text=command))
}

# Set plot size
X11(width=6.4, height=6.4)


#### Start plotting, running a loop for each team in tourneyteams
for (item in seq(along=tourneyteams)) {
  team <- tourneyteams[item]
  teamname <- agg.team[team, "team_name"]
  team_ind_games <- ind.team[ind.team$thisteam_team_id == team, ]
  rows_in_team_ind_games <- nrow(team_ind_games)
  
  # Create bar graphs for each aggregate team stat
  for (variable in seq(along=agg.team.plot)) {
    tryCatch({
      gen_var_name <- agg.team.plot[variable]
      gen_thisteam_var_name <- paste0("team_", gen_var_name)
      gen_opp_var_name <- paste0("opp_team_", gen_var_name)
      tmp_thisteam_stat_df <- subset(agg.team, team_name == teamname, select = c("team_name", gen_thisteam_var_name))
      colnames(tmp_thisteam_stat_df) <- c("team", "vals")
      tmp_opp_stat_df <- subset(agg.team, team_name == teamname, select = c(gen_opp_var_name))
      colnames(tmp_opp_stat_df) <- c("vals")
      tmp_opp_stat_df$team <- c ("Opposing Teams")
      command <- paste0('tmp_avg_stat_df <- data.frame(team=c("National Average", "Tournament Average"), vals=c(mean(agg.team$team_', gen_var_name, ', na.rm=TRUE), mean(tourney_team_agg_stats$team_', gen_var_name, ', na.rm=TRUE)))')
      eval(parse(text=command))
      tmp_stat_df <- rbind(tmp_thisteam_stat_df, tmp_opp_stat_df, tmp_avg_stat_df)
      
      tmp_stat_df$team <- factor(tmp_stat_df$team, c(teamname, 'Opposing Teams', 'National Average', 'Tournament Average'))
      eval(parse(text=paste0("min_avg <- range_team_agg_stats$", gen_var_name, "[1]")))
      eval(parse(text=paste0("max_avg <- range_team_agg_stats$", gen_var_name, "[3]")))
      range_avg = max_avg - min_avg
      p <- ggplot(data=tmp_stat_df, aes(x=team, y=vals, fill=team)) +
        geom_bar(stat="identity") +
        scale_y_continuous(limits=c(min_avg,max_avg), breaks=c(min_avg,((range_avg/8*1)+min_avg),((range_avg/8*2)+min_avg),((range_avg/8*3)+min_avg),((range_avg/8*4)+min_avg),((range_avg/8*5)+min_avg),((range_avg/8*6)+min_avg),((range_avg/8*7)+min_avg),max_avg), oob=rescale_none) +
        xlab("") +
        ylab(varnames[varnames$Variable == gen_var_name, "Text"]) +
        scale_fill_manual(values=c("#9E373E", "#319C86", "#999999", "#D1B993")) +
        guides(fill=FALSE) +
        theme_bw()
      p <- arrangeGrob(p, sub = textGrob("rodrigozamith.com", x = 0, hjust = -6, vjust=-0.3, gp = gpar(fontface = "italic", fontsize = 8)))
      plotfile = paste(team,"_team_agg_", gen_var_name, ".png", sep="")
      ggsave(filename=plotfile, path="plots/", width=6.4, height=6.4, plot=p, type = "cairo-png")
    }, error = function(e) NULL)
  }
  
  # Create boxplots for each individual team stat
  for (variable in seq(along=ind.team.plot)) {
    tryCatch({
      gen_var_name <- ind.team.plot[variable]
      gen_this_team_var_name <- paste0("thisteam_", gen_var_name)
      gen_opp_var_name <- paste0("opp_", gen_var_name)
      tmp_thisteam_stat_df <- subset(ind.team, thisteam_team_id == team, select = c("thisteam_team_name", gen_this_team_var_name))
      colnames(tmp_thisteam_stat_df) <- c("team", "vals")
      tmp_opp_stat_df <- subset(ind.team, thisteam_team_id == team, select = c(gen_opp_var_name))
      colnames(tmp_opp_stat_df) <- c("vals")
      tmp_opp_stat_df$team <- c ("Opposing Teams")
      tmp_stat_df <- rbind(tmp_thisteam_stat_df, tmp_opp_stat_df)
      
      tmp_stat_df$team <- factor(tmp_stat_df$team, c(teamname, 'Opposing Teams'))
      eval(parse(text=paste0("min_avg <- range_team_ind_stats$", gen_var_name, "[1]")))
      eval(parse(text=paste0("max_avg <- range_team_ind_stats$", gen_var_name, "[3]")))
      range_avg = max_avg - min_avg
      p <- ggplot(data=tmp_stat_df, aes(x=team, y=vals, fill=team)) +
        geom_jitter(aes(color = team), alpha = 0.4) +
        geom_boxplot(alpha = 0.7) +
        scale_y_continuous(limits=c(min_avg,max_avg), breaks=c(min_avg,((range_avg/8*1)+min_avg),((range_avg/8*2)+min_avg),((range_avg/8*3)+min_avg),((range_avg/8*4)+min_avg),((range_avg/8*5)+min_avg),((range_avg/8*6)+min_avg),((range_avg/8*7)+min_avg),max_avg), oob=rescale_none) +
        xlab("") +
        ylab(varnames[varnames$Variable == gen_var_name, "Text"]) +
        guides(fill=FALSE, color=FALSE) +
        theme_bw()
      p <- arrangeGrob(p, sub = textGrob("rodrigozamith.com", x = 0, hjust = -6, vjust=-0.3, gp = gpar(fontface = "italic", fontsize = 8)))
      plotfile = paste(team,"_team_ind_", gen_var_name, ".png", sep="")
      ggsave(filename=plotfile, path="plots/", width=6.4, height=6.4, plot=p, type = "cairo-png")
    }, error = function(e) NULL)
  }
  
  # Create boxplots for each individual player stat
  for (variable in seq(along=ind.player.plot)) {
    tryCatch({
      gen_var_name <- ind.player.plot[variable]
      tmp_stat_df <- subset(ind.player, team_id == team, select = c("player_name", gen_var_name))
      colnames(tmp_stat_df)[2] <- "vals"
      tmp_stat_df[is.na(tmp_stat_df)] <- 0
      
      # Plot it
      eval(parse(text=paste0("min_avg <- range_player_ind_stats$", gen_var_name, "[1]")))
      eval(parse(text=paste0("max_avg <- range_player_ind_stats$", gen_var_name, "[3]")))
      range_avg = max_avg - min_avg
      
      p <- ggplot(data=tmp_stat_df, aes(x=reorder(substring(player_name, 1, 20), -vals), y=vals, fill=player_name)) +
        geom_jitter(aes(color = player_name), alpha = 0.4) + geom_boxplot(alpha = 0.7) +
        scale_y_continuous(limits=c(min_avg,max_avg), breaks=c(min_avg,((range_avg/8*1)+min_avg),((range_avg/8*2)+min_avg),((range_avg/8*3)+min_avg),((range_avg/8*4)+min_avg),((range_avg/8*5)+min_avg),((range_avg/8*6)+min_avg),((range_avg/8*7)+min_avg),max_avg), oob=rescale_none) +
        #xlab("Player Name") +
        xlab("") +
        ylab(varnames[varnames$Variable == gen_var_name, "Text"]) +
        guides(fill=FALSE, color=FALSE) + theme_bw() + theme(axis.text.x=element_text(angle = 330, hjust = 0))
      p <- arrangeGrob(p, sub = textGrob("rodrigozamith.com", x = 0, hjust = -6, vjust=-0.3, gp = gpar(fontface = "italic", fontsize = 8)))
      plotfile = paste(team,"_player_ind_", gen_var_name, ".png", sep="")
      ggsave(filename=plotfile, path="plots/", width=6.4, height=6.4, plot=p, type = "cairo-png")
    }, error = function(e) NULL)
  }
  
  # Create date-based line graph for each team stat
  for (variable in seq(along=ind.team.plot)) {
    tryCatch({
      gen_var_name <- ind.team.plot[variable]
      gen_this_team_var_name <- paste0("thisteam_", gen_var_name)
      gen_opp_var_name <- paste0("opp_", gen_var_name)
      tmp_thisteam_stat_df <- subset(ind.team, thisteam_team_id == team, select = c("thisteam_team_name", "game_date", gen_this_team_var_name))
      colnames(tmp_thisteam_stat_df) <- c("team", "game_date", "vals")
      tmp_opp_stat_df <- subset(ind.team, thisteam_team_id == team, select = c("game_date", gen_opp_var_name))
      colnames(tmp_opp_stat_df) <- c("game_date", "vals")
      tmp_opp_stat_df$team <- c ("Opposing Teams")
      tmp_stat_df <- rbind(tmp_thisteam_stat_df, tmp_opp_stat_df)
      tmp_stat_df[is.na(tmp_stat_df)] <- 0
      
      # Plot it
      eval(parse(text=paste0("min_avg <- range_team_ind_stats$", gen_var_name, "[1]")))
      eval(parse(text=paste0("max_avg <- range_team_ind_stats$", gen_var_name, "[3]")))
      range_avg = max_avg - min_avg
      p <- ggplot(data=tmp_stat_df, aes(x=game_date, y=vals, group=team, color=team)) +
        geom_line() +
        scale_y_continuous(limits=c(min_avg,max_avg), breaks=c(min_avg,((range_avg/8*1)+min_avg),((range_avg/8*2)+min_avg),((range_avg/8*3)+min_avg),((range_avg/8*4)+min_avg),((range_avg/8*5)+min_avg),((range_avg/8*6)+min_avg),((range_avg/8*7)+min_avg),max_avg), oob=rescale_none) +
        xlab("") +
        ylab(varnames[varnames$Variable == gen_var_name, "Text"]) +
        labs(color="") +
        theme_bw() +
        theme(axis.text.x=element_text(angle = 330, hjust = 0), legend.position="bottom")
      p <- arrangeGrob(p, sub = textGrob("rodrigozamith.com", x = 0, hjust = -6, vjust=-0.3, gp = gpar(fontface = "italic", fontsize = 8)))
      plotfile = paste(team,"_team_time_", gen_var_name, ".png", sep="")
      ggsave(filename=plotfile, path="plots/", width=6.4, height=6.4, plot=p, type = "cairo-png")
    }, error = function(e) NULL)
  }
  
  # Create a percentile graph for each stat (This might be a bit confusing since high own-team = good, high opp-team = bad. Ideally, you want high, low, respectively.)
  tmp_stat_df <- subset(tourney_team_agg_stats.percentile, team_name == teamname, select = c("team_name", "variable", "percentile"))
  tmp_stat_df$variable <- factor(tmp_stat_df$variable, c("team_fgpct", "opp_team_fgpct", "team_three_fgpct", "opp_team_three_fgpct", "team_ptsavg", "opp_team_ptsavg", "team_offreb", "opp_team_offreb", "team_rebavg", "opp_team_rebavg", "team_ast", "opp_team_ast", "team_to", "opp_team_to", "team_stl", "opp_team_stl", "team_blk", "opp_team_blk", "team_avg_ptsdiff", "opp_team_avg_ptsdiff"))
  
  p <- ggplot(data=tmp_stat_df, aes(x=variable, y=percentile, fill=percentile)) +
    geom_bar(stat="identity") +
    theme(legend.position = "none", axis.text.x=element_text(size=10, angle = 90, hjust = 0)) +
    scale_x_discrete(expand = c(0, 0), labels=c("FG Pct", "Opp FG Pct", "3Pt Pct", "Opp 3Pt Pct", "Avg Pts", "Opp Avg Pts", "Offensive Reb", "Opp Off Reb", "Avg Reb", "Opp Avg Reb", "Assists", "Opp Assists", "Turnovers", "Opp Turnovers", "Steals", "Opp Steals", "Blocks", "Opp Blocks", "Avg Point Diff", "Opp Avg Pt Diff")) +
    ylim(0, 1) +
    xlab("") +
    ylab("Percentile (relative to tournament teams)") +
    scale_fill_gradient(low = "#4199c4", high = "#d12d10") +
    guides(fill=FALSE)
  p <- arrangeGrob(p, sub = textGrob("rodrigozamith.com", x = 0, hjust = -6, vjust=-0.3, gp = gpar(fontface = "italic", fontsize = 8)))
  plotfile = paste(team,"_team_spe_percentile.png", sep="")
  ggsave(filename=plotfile, path="plots/", width=6.4, height=6.4, plot=p, type = "cairo-png")
}